# -*- coding: utf-8 -*-
"""
Created on Sat Aug 21 14:02:51 2021

@author: poujo
"""
import numpy as np
import glob 
import os 
import textwrap as txtwrap

def extractInfo(filename="MoW.xml", exportname="2Translate.txt"):
    f = open(filename, 'r')
    fullFile = f.read()
    i = 0;
    infoText = ""
    while i != -1:
        i=fullFile.find("info=\"")
        if i!=-1:

            endi = fullFile[i+6:].find('"')
            infoText = infoText+fullFile[i+5:i+6+endi+1]+"\n~\n"
            fullFile = fullFile[i+6+endi+1:]

    f1 = open(filename[0:-4]+exportname, 'a')
    f1.truncate(0)
    f1.write(infoText)
    f1.close()
    f.close()

    print("EXTRACTION DONE!")
    return()

# def extractInfo(filename):
#     # Open the file as f.
#     # The function readlines() reads the file.
#     with open(filename) as f:
#         content = f.read()

#     # Show the file contents line by line.
#     # We added the comma to print single newlines and not double newlines.
#     # This is because the lines contain the newline character '\n'.
#     pos = 0;
#     FullTxt =[];
#     while pos != -1:
#         pos = content.find("info");
#         if pos != -1:
#             endText = pos+6;
#             s = content[endText];
#             while s!='"':
#                 s = content[endText];
#                 endText += 1;
#             text = content[pos+6:endText-1]
#             #FullTxt += text+"\n~\n";
#             FullTxt += [text];
#             #print(text)
#             #print("------")
#             content = content[endText:];
#             pos = 0;
#     return FullTxt

def affiche(text):
    txt = "";
    for t in text:
        txt += "\""+t+"\"";
        txt += "\n~\n"
    return txt;

def createTranslation(filesource="MoW.xml",filetarget="MoW_Blish.xml",translation="infoWithoutChariot.txt"):
    f = open(filesource,'r')
    oTxt = f.read();
    f1 = open(filetarget,'a')
    f1.truncate(0)
    f2 = open(translation,'r')
    infoT = f2.read()
    infoT = infoT.split("\n~\n")
    t = 0;

    i = 0;
    Text = ""
    while i != -1:
        i=oTxt.find("info=\"")
        if i!=-1:

            endi = oTxt[i+6:].find('"')
            Text = Text+oTxt[:i+5]+infoT[t]
            t += 1
            oTxt = oTxt[i+6+endi+1:]

    Text = Text + oTxt
    f1.write(Text)

    f1.close()
    f.close()
    f2.close()
    print("TRANSLATION CREATED")
    return()

def createTranslationUsingPrefixes(filesource="MoW.xml",filetarget="MoW_Universal.xml",translation="infoWithChariot.txt"):
    #This produces a file that can be used by either TacO or Blish-HUD and will have good displaying on both 
    f = open(filesource,'r', newline='\n')
    oTxt = f.read();
    f1 = open(filetarget,'a', newline='\n')
    f1.truncate(0)
    f2 = open(translation,'r', newline='\n')
    infoT = f2.read()
    infoT = infoT.split("\n~\n")
    t = 0;

    i = 0;
    Text = ""
    while i != -1:
        i=oTxt.find("info=\"")
        if i!=-1:

            endi = oTxt[i+6:].find('"')
            trying = infoT[t]
            Text = Text+oTxt[:i+5]+infoT[t]+" bh-info=\""+oTxt[i+6:i+6+endi+1]
            t += 1
            oTxt = oTxt[i+6+endi+1:]

    Text = Text + oTxt
    f1.write(Text)

    f1.close()
    f.close()
    f2.close()
    print("UNIVERSAL TRANSLATION CREATED")
    return()
        

def concatenateAll(optionfile="_MoW_Options.xml",path="allBlish/"):
    #path = "all/"
    FullTxt = "";
    nOfFile = 1;
    f0 = open(optionfile)
    txt = f0.readlines()[:-1]
    txt = "".join(txt);
    FullTxt = FullTxt+txt+"    <POIs>\n";
    for filename in glob.glob(os.path.join(path,'*.xml')):
       with open(os.path.join(os.getcwd(), filename), 'r') as f: # open in readonly mode
           txt = f.readlines()[2:-2];
           txt = "".join(txt);
           FullTxt = FullTxt+txt;
           nOfFile += 1;
    
    FullTxt += "	</POIs>\n</OverlayData>"
    #print(FullTxt)
    f1 = open("MoW.xml",'a', newline='')
    f1.truncate(0)
    f1.write(FullTxt)
    f1.close()
    print("CONCATENATION: DONE")
    return()


def addChariot(filename="info.txt"):
    infofilename = filename;
    with open(infofilename, "r") as f:
             info = f.read().split('\n~\n') 
    
    withoutNewline = "";
    for i in info:
        info_with_chariot = "\n".join(txtwrap.wrap(i,width=120));
        withoutNewline = withoutNewline+info_with_chariot+"\n~\n"
    
    f1 = open("infoWithChariot.txt", 'w', newline="\n")
    f1.truncate(0)
    f1.write(withoutNewline)
    f1.close()
    f.close()
    print("CHARIOT ADDED: DONE !!!")
    return


"""
def addChariot(filename="info.txt"):
    infofilename = filename;
    with open(infofilename) as f:
             info = f.read().split('\n~\n') 
    
    withoutNewline = "";
    for i in info:
        pos = 0;
        while pos+80<len(i):
            i=i[0:pos+120]+"\n"+i[pos+120:];
            pos=pos+121;
        withoutNewline = withoutNewline+i+"\n~\n"
    
    f1 = open("infoWithChariot.txt", 'a')
    f1.truncate(0)
    f1.write(withoutNewline)
    f1.close()
    f.close()
    print("CHARIOT ADDED: DONE !!!")
    return
"""
    
def deleteChariot(filename="info.txt"):
    infofilename = filename;
    with open(infofilename) as f:
             info = f.read().split('~') 
    
    withoutNewline = "";
    for i in info:
        pos = 0;
        indinit = 0;
        while pos!=-1:
            keep = 0;
            pos = i[indinit:].find("\n");
            if (pos!=-1 and pos+1<len(i) and i[pos+1]=="\n") or (pos!=-1 and pos<40):
                keep = 1;
                indinit = indinit+pos+1;
            if pos!=-1 and keep==0:
                indinit = indinit+pos
                i=i[:indinit]+" "+i[indinit+1:];
                indinit = indinit+pos+1
                
            
        withoutNewline = withoutNewline+i+"\n~\n"
    
    f1 = open("infoWithoutChariot.txt", 'a')
    f1.truncate(0)
    f1.write(withoutNewline)
    f1.close()
    f.close()
    print("CHARIOT REMOVED: DONE !!!")
    return

## USEFUL FUNCTIONS    
"""Transforme un pack avec des tag info formates pour TacO en pack formate pour Blish"""    
def TacO2Blish():
    deleteChariot(filename="MoWinfo.txt");
    createTranslation();
    print("Blish xml now Ready")
    return

def Blish2Taco():
    addChariot(filename="MoWinfo.txt");
    createTranslation(filetarget="MoW_TacO.xml",translation="infoWithChariot.txt");
    print("TacO xml now Ready")
    return

def Blish2Universal():
    addChariot(filename="MoWinfo.txt");
    print("Using both \"info\" content with and without linebreaks for universality")
    print("Taking advantage of prefixed arguments in xml")
    createTranslationUsingPrefixes();
    print("MoW_Universal.xml now Ready")
    return
"""Compile tous les documents xml pour construire le fichier .xml principal
Cree en outre le fichier avec les tags info adaptes a Blish"""
def createMoWFromTaco():
    #Comme on va utiliser le MoW.xml genere pour traduire en
    #MoW_Blish.xml, on utilise directement les bonnes options
    #A la fin on regenere le MoW.xml avec les options par defauts!
    concatenateAll(optionfile="0MoWBlish_Options.xml",path="all/")
    extractInfo(filename="MoW.xml", exportname="info.txt")
    TacO2Blish()
    concatenateAll(path="all/")
    return

"""Compile tous les documents xml pour construire le fichier .xml principal
Cree en outre le fichier avec les tags info adaptes a TacO"""
def createMoW():
    #Comme on va utiliser le MoW.xml genere pour traduire en
    #MoW_TacO.xml, on utilise directement les bonnes options (celles par défaut)
    #A la fin on regenere le MoW.xml avec les options pour Blish.
    concatenateAll()
    print('Extracting "info" content from MoW.xml fornatted without linebreaks')
    extractInfo(filename="MoW.xml", exportname="info.txt")
    Blish2Universal()
    concatenateAll(optionfile="0MoWBlish_Options.xml")
    return

def createMoW_Universal():
    #Comme on va utiliser le MoW.xml genere pour traduire en
    #MoW_TacO.xml, on utilise directement les bonnes options (celles par défaut)
    #A la fin on regenere le MoW.xml avec les options pour Blish.
    concatenateAll(optionfile="Universal_Options.xml")
    extractInfo(filename="MoW.xml", exportname="info.txt")
    Blish2Universal()
    return


"""Extrait les tags infos des fichiers specifies et les ecrits dans des fichiers de
nom similaire"""
def createFile2Translate():
    Filenames=["Wayfarer.xml",
"Ashford.xml",
"Bloodtide.xml",
"Brisban.xml",
"Caledon.xml",
"Champions.xml",
"Diessa.xml",
"Gendarran.xml",
"Harathi.xml",
"History.xml",
"Kessex.xml",
"Lornar.xml",
"Maelstrom.xml",
"Metrica.xml",
"Queensdale.xml",
"Ruins.xml",
"Snowden.xml",
"Sparkfly.xml",
"Steppes.xml",
"Straits.xml"]
    for fn in Filenames:
        extractInfo(filename="all/"+fn)
    extractInfo()
    
def TacO2BlishFile(f):
    extractInfo(filename=f+".xml", exportname="info.txt")
    deleteChariot(filename=f+"info.txt");
    createTranslation(filesource=f+".xml",filetarget=f+"_Blish.xml",translation="infoWithoutChariot.txt");
    print("Blish xml now Ready")
    return
    
    
#createMoW()
createMoW_Universal()


    
    