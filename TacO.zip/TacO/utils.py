"""Idée est d'ouvrir le fichier, de lire jusqu'à "info=", de récupérer toute la chaîne de caractères jusqu'à \" et reproduire la procédure sur le reste du fichier. On sépare les paragraphes par le signe "~" """

def extractInfo(filepath="D:\\root\\Documents\\GW2\\", filename="MoW.xml", exportname="D:\\root\\Documents\\GW2\\"):
    f = open(filepath+filename, 'r')
    fullFile = f.read()
    i = 0;
    infoText = ""
    while i != -1:
        i=fullFile.find("info=\"")
        if i!=-1:

            endi = fullFile[i+6:].find('"')
            infoText = infoText+fullFile[i+5:i+6+endi+1]+"\n~\n"
            fullFile = fullFile[i+6+endi+1:]

    f1 = open(exportname+filename+"info.txt", 'a')
    f1.truncate(0)
    f1.write(infoText)
    f1.close()
    f.close()

    print("EXTRACTION DONE!")
    return()

def createTranslation(path="D:\\root\\Documents\\GW2\\"):
    f = open(path+"MoW.xml",'r')
    oTxt = f.read();
    f1 = open(path+"MoW_FR.xml",'a')
    f1.truncate(0)
    f2 = open(path+"translation.txt")
    infoT = f2.read()
    infoT = infoT.split("\n~\n")
    t = 0;

    i = 0;
    Text = ""
    while i != -1:
        i=oTxt.find("info=\"")
        if i!=-1:

            endi = oTxt[i+6:].find('"')
            Text = Text+oTxt[:i+5]+infoT[t]
            t += 1
            oTxt = oTxt[i+6+endi+1:]

    Text = Text + oTxt
    f1.write(Text)

    f1.close()
    f.close()
    f2.close()
    print("TRANSLATION CREATED")
    return()

 
"""
extractInfo()
createTranslation()
"""
if True:
    Filenames=["Wayfarer.xml",
                "Ashford.xml",
                "Brisban.xml",
                "Caledon.xml",
                "Diessa.xml",
                "Gendarran.xml",
                "GendarranAlt.xml",
                "Harathi.xml",
                "History.xml",
                "Kessex.xml",
                "Lornar.xml",
                "Metrica.xml",
                "Queensdale.xml",
                "Ruins.xml",
                "Snowden.xml"]
    for fn in Filenames:
        extractInfo(filename="\\TacO\\all\\"+fn)
